package com.example.swiftcheckin;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AnnoucementActivity extends AppCompatActivity {

//    private TextView eventName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendee_announcement);

        Toast.makeText(this, "fdsfdsfds", Toast.LENGTH_SHORT).show();

        }
    }
